<?php 
	$consumer_key = '2INxXk2f1S0EjBfhoV8A3c5mb';
	$consumer_secret = 'nlKWQM8J4hvRfkGy2ixDhQ6aKN2kMX1ddUXrjiKdw29i4OcniN';
	$access_token = '1110227126119071744-FSlczyJxfGQTEc370XpMtk6EF5Ue54';
	$access_token_secret = '3Q7ur9nN46RPydxtBghPBp4deURSefGx6BXdeQrorbvoW';

require "twitteroauth/autoload.php";
use Abraham\TwitterOAuth\TwitterOAuth;

$connection = new TwitterOAuth(
	$consumer_key,
	$cosumer_secret,
	$access_token,
	$access_token_secret);

		$content = $connection -> get ("account/verify_credentials");

		$new_status = $connection->post("statuses/update", ["status" => "This is a Tweet"]);

		$statuses = $connection -> get ("statuses/home_timeline", ["count" => 25, "exclude_replies" => true]);

print_r($statuses);

