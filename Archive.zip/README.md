# 3720 Assignment 3

## Project Objective:
* Get data from Twitter API
* Add JavaScript to the data and render in HTML
* CSS design for the output

## Compatibility:
* The script will not render on MACOSX (AMPSS) application. 


## Live version:
https://alik.graphics/3720

## Description:
The script is simply grabs data from Twitter and show on the screen.

Input is what user want to search. The script will run for any hashtag according to the user' input.
Output is: 
1. Date
2. User Profile picture:
3. Tweet including the hashtag (user input)
4. Username

Since the program is so small I focused on design to create a better look for this simple function by using fixed header and footer and a simple table in center where data shows up. The search textarea is fixed on the top of the screen so users can search for other hashtags without refresh or going back.

All the codes are either from class or by me.
